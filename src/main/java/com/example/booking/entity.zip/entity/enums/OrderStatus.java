package com.example.booking.entity.enums;

public enum OrderStatus {
    NEW,
    CANCELED,
    FULFILLED
}
