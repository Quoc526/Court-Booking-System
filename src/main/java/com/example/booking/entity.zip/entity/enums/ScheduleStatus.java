package com.example.booking.entity.enums;

public enum ScheduleStatus {
    AVAILABLE,
    BOOKED,
    BLOCKED
}
