package com.example.booking.entity.enums;

public enum BillStatus {
    PENDING,
    PAID,
    REFUNDED
}
