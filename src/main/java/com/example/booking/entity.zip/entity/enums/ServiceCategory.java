package com.example.booking.entity.enums;

public enum ServiceCategory {
    DRINK,
    RACKET,
    BALL,
    OTHER
}
