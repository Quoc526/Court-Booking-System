package com.example.booking.entity.enums;

public enum PaymentMethod {
    CASH,
    CARD,
    OTHER
}
