package com.example.booking.entity.enums;

public enum CourtStatus {
    ACTIVE,
    INACTIVE
}
