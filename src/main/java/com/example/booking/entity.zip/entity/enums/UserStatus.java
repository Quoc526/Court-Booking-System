package com.example.booking.entity.enums;

public enum UserStatus {
    ACTIVE,
    BLOCKED
}
