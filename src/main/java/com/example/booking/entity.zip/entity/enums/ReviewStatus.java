package com.example.booking.entity.enums;

public enum ReviewStatus {
    PENDING,
    APPROVED,
    HIDDEN
}
